<?php
    echo "<h1> 🚨🤪 Área Restrita 🤪🚨 </h1>";

    echo "<p> Você não deveria estar aqui, mas conseguiu acessar devido a uma falha de segurança! </p>";

    echo "<p> Isso mostra como ataques SQL Injectio podem comprometer sistemas sem proteção adequeada. </p>";

    echo "<br><br><address> Lara Gorito Barbosa de Souza / Técnico em Desenvolvimento de Sistemas </address>";
?>